import base64
import json 
import pandas as pd
import boto3
import io

def convert_to_json(payload,schema):
    values = payload.strip().split(',')
    if len(values) == len(schema):
        item = {}
        for i in range(len(schema)):
            item[schema[i]] = values[i]
        return item


def lambda_handler(event, context):
    output = []
 
    schema = ["DCPower","ACPower","SunlightIntensity","DailyYield","temperature","state","city","masterid"]
    for record in event['records']:
        payload = base64.b64decode(record['data']).decode('utf-8')
        print("payload_is:",payload)
        json_data = convert_to_json(payload,schema)
        print(json_data)
        output_record = {
            'recordId': f"{record['recordId']}",
            'result': 'Ok',
            'data': base64.b64encode(json.dumps(json_data).encode('utf-8')).decode('utf-8')
        }
        output.append(output_record)

    print('Successfully processed {} records.'.format(len(event['records'])))
    return {'records': output}
