import json

def lambda_handler(event, context):
    # TODO implement 
    print(event)
    result = event['number1']+event['number2']
    if result%2 == 0:
        is_even = True
    else:
        is_even = False
    
    return {'is_even':is_even,'result':result}
